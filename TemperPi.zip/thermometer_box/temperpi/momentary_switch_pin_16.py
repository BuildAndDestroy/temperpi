#!/usr/bin/env python3
"""Testing only. This tests for '1' or '0'.

Testing only. This verifies the raspberry pi sees a 1 or 0
when the momentary switch is pushed.
"""

import time

###Import Libraries###
import RPi.GPIO as GPIO

###Initiate The GPIO Pins###
GPIO.setmode(GPIO.BCM)
#Switches#
GPIO.setup(16, GPIO.IN, pull_up_down=GPIO.PUD_DOWN)

###Test Switch For Pin 16###
print(GPIO.input(16))

###Cleanup###
GPIO.cleanup()