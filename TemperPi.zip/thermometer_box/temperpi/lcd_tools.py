#!/usr/bin/env python3
"""The wiring for the LCD is as follows:

1 : GND
 2 : 5V
 3 : Contrast (0-5V)*
 4 : RS (Register Select)
 5 : R/W (Read Write)       - GROUND THIS PIN
 6 : Enable or Strobe
 7 : Data Bit 0             - NOT USED
 8 : Data Bit 1             - NOT USED
 9 : Data Bit 2             - NOT USED
 10: Data Bit 3             - NOT USED
 11: Data Bit 4
 12: Data Bit 5
 13: Data Bit 6
 14: Data Bit 7
 15: LCD Backlight +5V**
 16: LCD Backlight GND
"""
import time

import reaper_ip
import RPi.GPIO as GPIO
import thermometer.temp_reading_87 as therm
import thermometer.temp_reading_f5 as therm


class GPIOSetup(object):
    """docstring for GPIOSetup"""

    def __init__(self):
        # Define GPIO to LCD mapping
        self.lcd_rs = 25
        self.lcd_e = 24
        self.lcd_d4 = 23
        self.lcd_d5 = 17
        self.lcd_d6 = 21
        self.lcd_d7 = 22
        # Define some device constants
        self.lcd_width = 16    # Maximum characters per line
        self.lcd_chr = True
        self.lcd_cmd = False
        self.lcd_line_1 = 0x80  # LCD RAM address for the 1st line
        self.lcd_line_2 = 0xC0  # LCD RAM address for the 2nd line
        # Timing constants
        self.e_pulse = 0.0005
        self.e_delay = 0.0005

    def lcd_string(self, message, line):
        """Send string to display"""
        message = message.ljust(self.lcd_width, " ")

        lcd_byte(line, self.lcd_cmd)

        for i in range(self.lcd_width):
            lcd_byte(ord(message[i]), self.lcd_chr)

    def program_block(self):
        """Main program block"""
        GPIO.setwarnings(False)
        GPIO.setmode(GPIO.BCM)       # Use BCM GPIO numbers
        GPIO.setup(self.lcd_e, GPIO.OUT)  # E
        GPIO.setup(self.lcd_rs, GPIO.OUT)  # RS
        GPIO.setup(self.lcd_d4, GPIO.OUT)  # DB4
        GPIO.setup(self.lcd_d5, GPIO.OUT)  # DB5
        GPIO.setup(self.lcd_d6, GPIO.OUT)  # DB6
        GPIO.setup(self.lcd_d7, GPIO.OUT)  # DB7

    def lcd_init(self):
        """Initialise display"""
        lcd_byte(0x33, self.lcd_cmd)  # 110011 Initialise
        lcd_byte(0x32, self.lcd_cmd)  # 110010 Initialise
        lcd_byte(0x06, self.lcd_cmd)  # 000110 Cursor move direction
        lcd_byte(0x0C, self.lcd_cmd)  # 001100 Display On,Cursor Off, Blink Off
        # 101000 Data length, number of lines, font size
        lcd_byte(0x28, self.lcd_cmd)
        lcd_byte(0x01, self.lcd_cmd)  # 000001 Clear display
        time.sleep(self.e_delay)

    def lcd_byte(self, bits, mode):
        """Send byte to data pins
        bits = data
        mode = True  for character
               False for command
        """
        GPIO.output(self.lcd_rs, mode)  # RS

        # High bits
        GPIO.output(self.lcd_d4, False)
        GPIO.output(self.lcd_d5, False)
        GPIO.output(self.lcd_d6, False)
        GPIO.output(self.lcd_d7, False)
        if bits & 0x10 == 0x10:
            GPIO.output(self.lcd_d4, True)
        if bits & 0x20 == 0x20:
            GPIO.output(self.lcd_d5, True)
        if bits & 0x40 == 0x40:
            GPIO.output(self.lcd_d6, True)
        if bits & 0x80 == 0x80:
            GPIO.output(self.lcd_d7, True)

        # Toggle 'Enable' pin
        lcd_toggle_enable()

        # Low bits
        GPIO.output(self.lcd_d4, False)
        GPIO.output(self.lcd_d5, False)
        GPIO.output(self.lcd_d6, False)
        GPIO.output(self.lcd_d7, False)
        if bits & 0x01 == 0x01:
            GPIO.output(self.lcd_d4, True)
        if bits & 0x02 == 0x02:
            GPIO.output(self.lcd_d5, True)
        if bits & 0x04 == 0x04:
            GPIO.output(self.lcd_d6, True)
        if bits & 0x08 == 0x08:
            GPIO.output(self.lcd_d7, True)

        # Toggle 'Enable' pin
        lcd_toggle_enable()

    def lcd_toggle_enable(self):
        """Toggle enable"""
        time.sleep(self.e_delay)
        GPIO.output(self.lcd_e, True)
        time.sleep(self.e_pulse)
        GPIO.output(self.lcd_e, False)
        time.sleep(self.e_delay)

    def cleanup_shutdown(self):
        """Print shutdown and cleanup pins"""
        lcd_byte(0x01, self.lcd_cmd)
        lcd_string(" Shutting down!", self.lcd_line_1)
        lcd_string("    Good Bye!", self.lcd_line_2)
        GPIO.cleanup()

    def lcd_16x2_temp(self):
        """Init gpio and print temperature."""
        lcd_on = GPIOSetup()
        lcd_on.lcd_init()
        while True:
            # Send some test
            lcd_string("  Temperature", self.lcd_line_1)
            lcd_string("    C and F", self.lcd_line_2)

            time.sleep(3)  # 3 second delay

            # Send some text
            lcd_string("S-1 C*     F*", self.lcd_line_1)
            lcd_string(therm.read_temp(), self.lcd_line_2)

            time.sleep(3)  # 3 second delay

            lcd_string("S-2 C*     F*", self.lcd_line_1)
            lcd_string(therm.read_temp(), self.lcd_line_2)

            time.sleep(3)  # 3 second delay

            lcd_string("   Done, son!", self.lcd_line_1)
            lcd_string("     t(-_-t)", self.lcd_line_2)

            time.sleep(2)

            lcd_byte(0x01, lcd_cmd)
        #    lcd_string("Push Blue Button",lcd_line_1)
        #    lcd_string("For Temperature",lcd_line_2)
            lcd_string(" Reaper-UT.com", self.lcd_line_1)
            lcd_string(reaper_ip.reaper_ip_f(), self.lcd_line_2)
            GPIO.cleanup()

            return

    def lcd_16x2_halting(self):
        """Print a system halt to lcd."""
        while True:
            lcd_on.lcd_string("System halting!", self.lcd_line_1)
            lcd_on.lcd_string("", self.lcd_line_2)
            time.sleep(2)
            return

    def lcd_16x2_shutdown(self):
        """Print shutdown and cleanup gpio."""
        while True:
            lcd_byte(0x01, self.lcd_cmd)
            lcd_string(" Shutting down!", self.lcd_line_1)
            lcd_string("    Good Bye!", self.lcd_line_2)
            GPIO.cleanup()


def main():
    """ Init the GPIOSetup Class."""
    lcd_on = GPIOSetup()

    #  Import program block.
    lcd_on.program_block()

    # Initialise display.
    lcd_on.lcd_byte()
    lcd_on.lcd_init()

    #  Display halting to lcd the shutdown.
    lcd_on.lcd_16x2_halting()
    lcd_on.lcd_16x2_shutdown()


if __name__ == '__main__':
    main()
