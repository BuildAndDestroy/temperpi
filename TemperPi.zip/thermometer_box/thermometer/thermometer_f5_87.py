#!/usr/bin/env python3
"""Initilize the thermometers.

Thermometers are pulled from static files for now.
Both thermometers are read then converted to Celsius and fahrenheit,
then printed out.
"""
import os
import time


class Thermometer(object):
    """docstring for thermometer"""

    def __init__(self):
        self.first_thermometer = '/sys/bus/w1/devices/28-80000007b187/w1_slave'
        self.second_thermometer = '/sys/bus/w1/devices/28-80000003f3f5/w1_slave'

    def therm1_87(self):
        """Return a thermometer."""
        return self.first_thermometer

    def therm1_f5(self):
        """Return a thermometer."""
        return self.second_thermometer


def temp_raw(therm):
    """Raw output for thermometer"""
    read_thermometer = open(therm, 'r')
    lines = read_thermometer.readlines()
    read_thermometer.close()
    return lines


def read_temp(temp_raw):
    """Strip down to tempurature and calculate C and F"""
    lines = temp_raw
    while lines[0].strip()[-3:] != 'YES':
        time.sleep(0.2)
        lines = temp_raw
    temp_output = lines[1].find('t=')
    if temp_output != -1:
        temp_string = lines[1].strip()[temp_output+2:]
        temperature_celsius = float(temp_string) / 1000.0
        temperature_fahrenheit = temperature_celsius * 9.0 / 5.0 + 32.0
        return temperature_celsius, temperature_fahrenheit


def return_87():
    """Load a thermometer then return."""
    os.system('modprobe w1-gpio')
    os.system('modprobe w1-therm')

    initilize_thermometer = Thermometer()

    return read_temp(temp_raw(initilize_thermometer.therm1_87()))


def return_f5():
    """Load a thermometer then return."""
    os.system('modprobe w1-gpio')
    os.system('modprobe w1-therm')

    initilize_thermometer = Thermometer()

    return read_temp(temp_raw(initilize_thermometer.therm1_f5()))


def main():
    """Load drives and print output."""
    os.system('modprobe w1-gpio')
    os.system('modprobe w1-therm')

    initilize_thermometer = Thermometer()

    print(read_temp(temp_raw(initilize_thermometer.therm1_87())))
    print(read_temp(temp_raw(initilize_thermometer.therm1_f5())))


if __name__ == '__main__':
    main()
