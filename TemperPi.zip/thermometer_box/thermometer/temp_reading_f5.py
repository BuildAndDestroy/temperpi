#!/usr/bin/env python3
"""Initilize one thermometer.

Thermometer is pulled from a static file for now.
T thermometer is read then converted to Celsius and fahrenheit,
then printed out.
"""
import os
import time


def temp_raw():
    """Raw output for thermometer"""
    second_slave = '/sys/bus/w1/devices/28-80000003f3f5/w1_slave'

    read_thermometer = open(second_slave, 'r')
    lines = read_thermometer.readlines()
    read_thermometer.close()
    return lines


def read_temp():
    """Strip down to tempurature and calculate C and F"""
    lines = temp_raw()
    while lines[0].strip()[-3:] != 'YES':
        time.sleep(0.2)
        lines = temp_raw()
    temp_output = lines[1].find('t=')
    if temp_output != -1:
        temp_string = lines[1].strip()[temp_output+2:]
        temperature_celsius = float(temp_string) / 1000.0
        temperature_fahrenheit = temperature_celsius * 9.0 / 5.0 + 32.0
        return temperature_celsius, temperature_fahrenheit


def main():
    """Load drives and print output."""
    os.system('modprobe w1-gpio')
    os.system('modprobe w1-therm')

    print(read_temp())


if __name__ == '__main__':
    main()
