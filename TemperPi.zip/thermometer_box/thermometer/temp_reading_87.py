#!/usr/bin/env python3
"""Initilize one thermometer.

Thermometer is pulled from a static file for now.
T thermometer is read then converted to Celsius and fahrenheit,
then printed out.
"""

import os
import time

# Load Drivers
# os.system('modprobe w1-gpio')
# os.system('modprobe w1-therm')


def temp_raw():
    """Raw output for thermometer"""
    first_thermometer = '/sys/bus/w1/devices/28-80000007b187/w1_slave'

    read_thermometer = open(first_thermometer, 'r')
    lines = read_thermometer.readlines()
    read_thermometer.close()
    return lines


def read_temp(arg):
    """Strip down to tempurature and calculate C and F"""
    lines = arg
    while lines[0].strip()[-3:] != 'YES':
        time.sleep(0.2)
        lines = temp_raw()
    temp_output = lines[1].find('t=')
    if temp_output != -1:
        temp_string = lines[1].strip()[temp_output+2:]
        temperature_celsius = float(temp_string) / 1000.0
        temperature_fahrenheit = temperature_celsius * 9.0 / 5.0 + 32.0
        return temperature_celsius, temperature_fahrenheit


def main():
    """Load drives and print output."""
    os.system('modprobe w1-gpio')
    os.system('modprobe w1-therm')

    print(read_temp(temp_raw()))


if __name__ == '__main__':
    main()
